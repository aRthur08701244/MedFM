conda create --name openmmlab python=3.8 -y
conda activate openmmlab
pip install -U openmim && mim install "mmpretrain>=1.0.0rc8"

pip install ipykernel
python -m ipykernel install --user --name openmmlab

pip install -U scikit-learn
pip install seaborn

cd ${YOUR_WORKING_DIR}

git clone https://github.com/open-mmlab/mmpretrain.git
cd mmpretrain

mkdir ~/MedFMC_DATA
move MedFMC_train_v2.zip to MedFMC_DATA/
move MedFMC_val_v2.zip to MedFMC_DATA/

cd ~/MedFMC_DATA/
upzip MedFMC_train_v2.zip
upzip MedFMC_val_v2.zip

mkdir chest
mkdir chest/images
mkdir colon
mkdir colon/images
mkdir endo
mkdir endo/images

mv MedFMC_train/chest/images/* chest/images/
mv MedFMC_train/colon/images/* colon/images/
mv MedFMC_train/endo/images/* endo/images/
mv MedFMC_val/chest/images/* chest/images/
mv MedFMC_val/colon/images/* colon/images/
mv MedFMC_val/endo/images/* endo/images/

mkdir pretrain
you can find them from 
https://mmpretrain.readthedocs.io/zh-cn/latest/papers/densenet.html
https://mmpretrain.readthedocs.io/zh-cn/latest/papers/beitv2.html
...
download pretrainend models and move them to pretrain/

soft link data
cd ${YOUR_WORKING_DIR}
mkdir data
mkdir data/MedFMC

ln -s ~/MedFMC_DATA/chest /data/MedFMC/
e.g. ln -s /service/amy2/arthur/MedFMC_DATA/chest data/MedFMC/
ln -s ~/MedFMC_DATA/colon /data/MedFMC/
e.g. ln -s /service/amy2/arthur/MedFMC_DATA/colon data/MedFMC/
ln -s ~/MedFMC_DATA/endo /data/MedFMC/
e.g. ln -s /service/amy2/arthur/MedFMC_DATA/endo data/MedFMC/

ln -s /service/amy2/arthur/MedFMC_DATA/work_dirs /home/arthur/hw/dlmi/HW/mmpretrain/

------------------------------------------------------------------------------------------------------

create new configs/densenet/densenet121_4xb256_in1k-chest.py

"""
_base_ = [
    '../_base_/models/densenet/densenet121-multilabel.py
    '../_base_/datasets/imagenet_bs64-chest.py',
    '../_base_/schedules/imagenet_bs256.py',
    '../_base_/default_runtime.py',
]

model = dict(
    backbone=dict(
        init_cfg=dict(
            type='Pretrained',
            checkpoint='pretrain/densenet121_4xb256_in1k_20220426-07450f99.pth',
            prefix='backbone',
        )),
    head=dict(num_classes=19))
"""

create new configs/_base_/datasets/imagenet_bs64-chest.py',

"""
dataset_type = 'ImageNet' => dataset_type = 'CustomDataset'
num_classes=1000 => num_classes=19
data_root='data/imagenet', split='train', => data_root='data/MedFMC/chest', ann_file='chest_label_train.txt', data_prefix='images', 
data_root='data/imagenet', split='val', => data_root='data/MedFMC/chest', ann_file='chest_label_val.txt', data_prefix='images', 
val_evaluator = dict(type='Accuracy', topk=(1, 5)) => val_evaluator = dict(type='AveragePrecision')
"""

create new configs/_base_/models/densenet121-multilabel.py

"""
type='LinearClsHead', => type='MultiLabelLinearClsHead',
del loss=dict(type='CrossEntropyLoss', loss_weight=1.0),
"""

cd mmpretrain
python tools/train.py configs/densenet/densenet121_4xb256_in1k-chest.py

# the last checkpoint file directory will be in last_checkpoint. So, open it and copy the path to the second argument
python tools/test.py configs/densenet/densenet121_4xb256_in1k-chest.py work_dirs/densenet121_4xb256_in1k-chest/epoch_200.pth
