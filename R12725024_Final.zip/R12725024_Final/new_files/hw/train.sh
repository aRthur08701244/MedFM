python tools/train.py configs/densenet/densenet121_4xb256_in1k-chest.py
python tools/train.py configs/densenet/densenet121_4xb256_in1k-colon.py
python tools/train.py configs/densenet/densenet121_4xb256_in1k-endo.py